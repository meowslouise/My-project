<?php
    echo 
    '<div id="top">
        <ul id="menu">
            <li ><a href="home_a.php">Home</a></li>
            <li ><a href="user_a.php">Users</a></li>
            <li ><a href="performer_a.php">Performer</a></li>
            <li ><a href="session_a.php">Sessions</a></li>
            <li ><a href="requests.php">Requests</a></li>
            <li ><a href="check_book.php">Bookings</a></li>
        </ul>
    </div>';
?>