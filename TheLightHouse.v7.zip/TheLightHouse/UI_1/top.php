<?php
    echo 
    '<div id="top">
        <ul id="menu">
            <li ><a href="home_c.php">Home</a></li>
            <li ><a href="myticket.php">Your Ticket</a></li>
            <li ><a href="account.php">Account</a></li>
        </ul>
    </div>';
?>