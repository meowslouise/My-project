<?php
    echo 
    '<div id="top">
        <ul id="menu">
            <li ><a href="home_p.php">Home</a></li>
            <li ><a href="reservation.php">Reservation</a></li>
            <li ><a href="mysession.php">Your Session</a></li>
            <li ><a href="account_p.php">Account</a></li>
        </ul>
    </div>';
?>